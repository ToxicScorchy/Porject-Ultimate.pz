# 🎮 Project Zomboid 3D Viewpoint & Mod Controls Guide

Welcome to the definitive user guide for the **Project Zomboid Ultimate 3D Overhaul**.

---

## 🕹️ Camera & 3D Perspective Keybindings

Once you load into a singleplayer or multiplayer world:

| Key / Shortcut | Action | Description |
| :--- | :--- | :--- |
| <kbd>O</kbd> | **Toggle 3D First-Person** | Snaps your camera directly between vanilla isometric and true first-person eye level. |
| <kbd>Shift</kbd> + <kbd>O</kbd> | **Switch Perspectives** | Seamlessly cycles between First-Person and Over-the-Shoulder Third-Person. |
| <kbd>Middle Mouse</kbd> | **Toggle Cursor Lock** | Locks the crosshair to FPS free-look mode, or unlocks cursor to click inventory loot & menus. |
| <kbd>Delete</kbd> | **Viewpoint In-Game HUD** | Opens the main 3D engine settings: Shader packs, FOV, render distance, and lighting. |
| <kbd>Insert</kbd> + <kbd>O</kbd> | **Freecam Mode** | Detaches the camera from the survivor skeleton for cinematic exploration. |
| <kbd>Left Alt</kbd> (Hold) | **Tactical Freelook** | Swivels character head without rotating your weapon aim or body. |

---

## 🎨 Activating the Minecraft "Insanity Shader"

The **Insanity Shader** pack is pre-installed in your `%USERPROFILE%\Zomboid\viewpoint-shaderpacks\` folder.

1. Launch Project Zomboid and load your world.
2. Press <kbd>Delete</kbd> to open the **Project Viewpoint Menu**.
3. Under **Shader Packs**, select **Insanity Shader** from the dropdown menu.
4. Under **Lighting Mode**, select **Default** or **Vivid** for rich atmospheric contrast.
5. Under **Model Packs**, select **Furniture Fix** to render world props, kitchen counters, and appliances in full 3D geometry.

---

## 🚗 Vehicle Mechanics & Features

With **that DAMN Library** and the KI5 vehicle collection active:

* **Vehicles Included**: '89 Land Rover Defender 90/110, '87 Toyota Land Cruiser, '86 Ford Econoline E150, '82 Oshkosh M911 Heavy Hauler, '86 Oshkosh P19A Military Truck, '67 Cadillac Gage V100 APC, '92 AM General Humvee, '59 Cadillac Miller-Meteor (Ecto-1), '82 Jeep J10, and '88 Chevy S10.
* **Fuel Indicators**: Fuel cap indicators on your HUD show which side of the vehicle has the gas tank.
* **Armor & Upgrades**: Reinforce windows, weld bullbars, install roof racks, and craft armored plating at metalworking benches.
* **Salvage & Repair**: Fully compatible with Vehicle Repair Overhaul B42.

---

## 🧟 In-Depth Mod Features & QoL

* **True Actions**: Right-click chairs, sofas, and beds to actually sit, sleep, or lie down.
* **Common Sense**: Pry open locked house doors and garage shutters using a Crowbar. Slice open canned food using a Hunting Knife.
* **Visible Slings**: Noir's Rifle Slings visually displays primary and secondary firearms strapped to your back in 3D.
* **Basements**: Find or construct underground bunkers immune to surface storms and helicopter noise.
* **Silent Hill OST**: Atmospheric horror music fades in dynamically during fog, rain, and darkness.

---

## ⚙️ Performance & Troubleshooting

### Increasing RAM manually
The installer automatically gives you 8GB RAM (`-Xmx8192m`). If you ever need to adjust this:
1. Open `C:\Steam\steamapps\common\ProjectZomboid\ProjectZomboid64.json`.
2. Locate `"-Xmx8192m"` and change to your desired value.

### Resetting Active Mods
If you ever want to re-apply the clean curated mod preset, simply run `install.bat` again, or copy `config/default.txt` to `%USERPROFILE%\Zomboid\mods\default.txt`.

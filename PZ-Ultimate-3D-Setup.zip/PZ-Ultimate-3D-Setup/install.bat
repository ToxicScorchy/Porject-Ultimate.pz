@echo off
title Project Zomboid Ultimate 3D & Modpack Setup
color 0A

:: Check for administrative rights / bypass execution policy
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"

echo.
echo Press any key to exit this window...
pause >nul
exit

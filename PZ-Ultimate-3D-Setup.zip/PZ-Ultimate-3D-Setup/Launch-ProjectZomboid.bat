@echo off
title Launch Project Zomboid (Ultimate 3D Modded)
color 0A

:: Search common Project Zomboid directories
set "PZ_DIR="
if exist "C:\Steam\steamapps\common\ProjectZomboid\ProjectZomboid64.exe" set "PZ_DIR=C:\Steam\steamapps\common\ProjectZomboid"
if exist "C:\Program Files (x86)\Steam\steamapps\common\ProjectZomboid\ProjectZomboid64.exe" set "PZ_DIR=C:\Program Files (x86)\Steam\steamapps\common\ProjectZomboid"
if exist "D:\Steam\steamapps\common\ProjectZomboid\ProjectZomboid64.exe" set "PZ_DIR=D:\Steam\steamapps\common\ProjectZomboid"
if exist "D:\SteamLibrary\steamapps\common\ProjectZomboid\ProjectZomboid64.exe" set "PZ_DIR=D:\SteamLibrary\steamapps\common\ProjectZomboid"

if "%PZ_DIR%"=="" (
    echo [ERROR] Project Zomboid directory not found automatically.
    echo Please run install.bat first!
    pause
    exit /b 1
)

:: Check Steam
tasklist /FI "IMAGENAME eq steam.exe" 2>NUL | find /I /N "steam.exe">NUL
if errorlevel 1 (
    echo Starting Steam client...
    start "" "C:\Steam\steam.exe"
    timeout /t 3 >nul
)

cd /d "%PZ_DIR%"
start "" ".\ProjectZomboid64.exe"
exit

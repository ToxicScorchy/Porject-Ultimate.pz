<div align="center">

# 🧟‍♂️ PROJECT ZOMBOID: ULTIMATE 3D OVERHAUL
### *Turn The Ultimate Isometric Survival Game into a Next-Gen First-Person Horror Simulator.*

[![Build Status](https://img.shields.io/badge/Build-42%20%26%2041%20Ready-brightgreen?style=for-the-badge&logo=steam)](https://store.steampowered.com/app/108600/Project_Zomboid/)
[![Java Heap](https://img.shields.io/badge/RAM%20Allocation-8GB%20Optimized-blue?style=for-the-badge&logo=oracle)](https://www.oracle.com/java/)
[![3D Engine](https://img.shields.io/badge/3D%20Engine-ZombieBuddy%20Native-orange?style=for-the-badge)](https://github.com/zed-0xff/ZombieBuddy)
[![Shader Support](https://img.shields.io/badge/Shaders-Insanity%20Universal-red?style=for-the-badge&logo=minecraft)](https://modrinth.com/shader/insanity-shader)
[![License](https://img.shields.io/badge/License-MIT-purple?style=for-the-badge)](LICENSE)

<br/>

> **"Experience Kentucky through the eyes of your survivor."**  
> *True First-Person & Over-The-Shoulder 3D • Minecraft Insanity Shaders • 93+ Hand-Curated Mods • Zero Conflicts • 8GB High-Performance Java Engine.*

<br/>

[📥 **Download 1-Click Release Package (.ZIP)**](https://github.com/ToxicScorchy/project-zomboid-ultimate-3d-setup/releases/latest) • [📖 **In-Game Controls**](docs/CONTROLS_AND_GUIDE.md) • [⚡ **Quick Start Guide**](#-quick-start-3-steps)

---

</div>

<br/>

## 🌟 Why Settle for Vanilla?

Project Zomboid is the greatest zombie survival sandbox ever made—but it was locked to an isometric 1990s perspective and capped at a tiny 3 GB of RAM by default. 

**This package unlocks the game's true potential.** With a single click, your game is transformed into an atmospheric, heart-pounding 3D survival experience powered by modern OpenGL rendering, hyper-detailed vehicles, authentic soundscapes, and rock-solid 8GB performance.

| Vanilla Experience 😐 | With Ultimate 3D Overhaul 🔥 |
| :--- | :--- |
| **Fixed top-down isometric view** | **Full First-Person & 3rd-Person over-the-shoulder 3D** |
| Flat 2.5D cardboard furniture & sprites | **Thousands of true 3D furniture, prop & appliance meshes** |
| Default 3072 MB RAM cap (frequent GC stutters) | **8192 MB (8GB) dedicated heap with low-latency ZGC** |
| Generic lighting and flat shadows | **Volumetric fog, moody vignette & Minecraft Insanity Shader** |
| Low-poly generic station wagons | **KI5 Military fleet: Oshkosh, Humvees, Land Rovers, APCs** |
| Weapon mod crashes & duplicated item IDs | **Zero-conflict curated suite tested for seamless play** |

<br/>

---

## ⚡ What's Inside The Package?

### 👁️ 1. Real-Time 3D Viewpoint Engine
Snap seamlessly between isometric and eye-level first-person with a single keypress. Aim down iron sights, peek around corners, look through vehicle windows, and experience the terror of hearing footfalls right behind you.
* **First-Person & Third-Person Camera** (<kbd>O</kbd> and <kbd>Shift</kbd>+<kbd>O</kbd>)
* **ZombieBuddy Bytecode Hook** injected natively into the game engine
* **Furniture Fix 3D Asset Pack** replacing thousands of flat environment sprites with true 3D geometry.

### 🌑 2. Minecraft "Insanity Shader" Universal Suite
Powered by experimental Iris OpenGL pipeline integration, load the acclaimed horror **Insanity Shader** directly into Project Zomboid.
* Dense volumetric mist rolling through Kentucky pine forests
* True dynamic flashlight beams slicing through pitch-black corridors
* Cold blue-gray color grading, subtle chromatic aberration, and cinematic vignette.

### 🚗 3. Legendary Armored & Military Fleet
* Fully interactive **'89 Land Rover Defender 90/110**, **'87 Toyota Land Cruiser**, **'92 AM General Humvee**, **'86 Oshkosh P19A**, **'82 Oshkosh M911 Hauler**, **'67 Cadillac Gage Commando APC**, **'86 Ford Econoline**, and **Armored RV Motorhomes**.
* Working fuel indicators, vehicle salvage overhaul, welded window armor, and metalworking craftables.

### 🎧 4. Unmatched Immersion & Mechanics
* **Silent Hill OST Atmosphere**: Dynamic ambient music that raises the hair on your neck during storms and dense fog.
* **True Actions**: Sit on armchairs, sleep in beds, and rest realistically.
* **Common Sense**: Pry open locked security doors and garage gates with a Crowbar. Crack open canned rations with your hunting knife.
* **Noir's 3D Visible Slings**: Rifles and shotguns physically render strapped across your survivor's back.
* **Underground Basements**: Discover or construct subterranean bunkers safe from surface helicopter events.
* **Expanded Map Universe**: Seamlessly expands Kentucky with Rosewood Expansion, Ashenwood, Chestown, and the Rosewood Military Hospital.

<br/>

---

## 🚀 Quick Start (3 Steps)

### Step 1: Download & Extract
1. Download the latest **[`PZ-Ultimate-3D-Setup.zip`](https://github.com/ToxicScorchy/project-zomboid-ultimate-3d-setup/releases/latest)**.
2. Extract the folder anywhere on your computer (e.g. your Desktop or Downloads).

### Step 2: Run 1-Click Installer
1. Double-click **`install.bat`**.
2. The installer will automatically:
   - 🔍 Detect your Project Zomboid and Steam directories.
   - 🚀 Upgrade your Java memory to **8 GB** (`-Xmx8192m`).
   - 💉 Inject the **ZombieBuddy** native 3D bytecode hook.
   - 📦 Install the **Insanity Shader Universal** pack.
   - 🛡️ Activate the **93+ curated conflict-free mod & map list**.
   - 🖥️ Place a direct **Launch Modded Project Zomboid** shortcut on your Desktop!

### Step 3: Subscribe to the 2 Steam Workshop Dependencies
Double-click **`Subscribe-Workshop-Mods.bat`** (or open these two links directly in Steam):
* [1. that DAMN Library (Workshop ID: 3171167894)](https://steamcommunity.com/sharedfiles/filedetails/?id=3171167894) — *Powers the vehicle fleet*
* [2. Project Viewpoint (Workshop ID: 3809306528)](https://steamcommunity.com/sharedfiles/filedetails/?id=3809306528) — *Powers the 3D rendering engine*

Click **Subscribe** on both, and you're done!

<br/>

---

## 🎮 In-Game Controls Cheat Sheet

| Key | Action | What It Does |
| :--- | :--- | :--- |
| <kbd>O</kbd> | **Toggle 3D View** | Instantly switches between classic isometric and eye-level First-Person. |
| <kbd>Shift</kbd> + <kbd>O</kbd> | **Switch Camera** | Cycles between First-Person and Over-the-Shoulder 3rd-Person. |
| <kbd>Middle Mouse</kbd> | **Cursor Lock** | Locks crosshair for mouse FPS looking / frees cursor for looting containers. |
| <kbd>Delete</kbd> | **Viewpoint Menu** | Opens settings: Select **Insanity Shader** and **Furniture Fix 3D Models** here! |
| <kbd>Left Alt</kbd> (Hold) | **Tactical Freelook** | Allows looking around while moving without breaking weapon aim. |
| <kbd>Insert</kbd> + <kbd>O</kbd> | **Freecam Mode** | Flyable camera for taking gorgeous screenshots and cinematic videos. |

<br/>

---

## 💻 Hardware Requirements

| Component | Minimum Recommended | Enthusiast / Ideal |
| :--- | :--- | :--- |
| **OS** | Windows 10 / 11 (64-bit) | Windows 11 (64-bit) |
| **CPU** | Quad-Core 3.0 GHz (Intel i5 / Ryzen 5) | Modern 6+ Cores (e.g. i5-13600K / Ryzen 7) |
| **RAM** | 16 GB Physical RAM (Installer gives 6GB to PZ) | 32 GB Physical RAM (Installer gives 8GB to PZ) |
| **GPU** | NVIDIA GTX 1060 / AMD RX 580 (4GB VRAM) | NVIDIA RTX 3060 / AMD RX 6700 XT (8GB+ VRAM) |
| **Storage** | 5 GB Free SSD Space | High-Speed NVMe SSD |

<br/>

---

## ❓ Frequently Asked Questions

<details>
<summary><b>Does this work with multiplayer or co-op?</b></summary>
Yes! The 3D camera and shaders run entirely on the client side. As long as the host or dedicated server runs the same mod IDs, you can play in 3D with friends.
</details>

<details>
<summary><b>Will this wipe my existing saves?</b></summary>
No. Your existing singleplayer and multiplayer save files are completely safe. The mod preset applies to new worlds or existing saves when you enable the mods in your save options.
</details>

<details>
<summary><b>How do I uninstall or revert?</b></summary>
The installer automatically creates backups (<code>ProjectZomboid64.json.bak</code>). To revert, simply rename the <code>.bak</code> file to <code>ProjectZomboid64.json</code> and delete the <code>default.txt</code> in <code>%USERPROFILE%\Zomboid\mods\</code>.
</details>

<details>
<summary><b>Why 8 GB RAM instead of the game's default 3 GB?</b></summary>
Project Zomboid's Java virtual machine easily exhausts 3072 MB when caching thousands of high-polygon 3D meshes and vehicle textures. Allocating 8192 MB completely eliminates garbage-collection freeze spikes and out-of-memory crashes.
</details>

<br/>

---

<div align="center">

### Ready to Experience Kentucky Like Never Before?
Double-click `install.bat` and jump into the apocalypse.

*Created with ❤️ for the Project Zomboid Community.*

</div>

@echo off
title 1-Click Steam Workshop Mod Subscription
color 0B

echo =======================================================================
echo          PROJECT ZOMBOID - 1-CLICK STEAM WORKSHOP OPENER
echo =======================================================================
echo.
echo Opening the essential companion workshop items in your Steam client:
echo.
echo [1] that DAMN Library (ID: 3171167894) - Required for 10+ vehicles
start steam://openurl/https://steamcommunity.com/sharedfiles/filedetails/?id=3171167894
timeout /t 2 >nul

echo [2] Project Viewpoint (ID: 3809306528) - Core 3D engine & shaders
start steam://openurl/https://steamcommunity.com/sharedfiles/filedetails/?id=3809306528
timeout /t 2 >nul

echo [3] ZombieBuddy (ID: 3619862853) - Java agent workshop page
start steam://openurl/https://steamcommunity.com/sharedfiles/filedetails/?id=3619862853
timeout /t 2 >nul

echo [4] Project ViewPoint: 3D Models [B42.21]
start steam://openurl/https://steamcommunity.com/workshop/browse/?appid=108600^&searchtext=Project+ViewPoint+3D+Models
timeout /t 2 >nul

echo [5] Third Person Camera for Project Viewpoint
start steam://openurl/https://steamcommunity.com/workshop/browse/?appid=108600^&searchtext=Third+Person+Camera+for+Project+Viewpoint

echo.
echo =======================================================================
echo  All pages launched in Steam! Simply click 'Subscribe' on each one.
echo  Once subscribed, double-click 'Launch Project Zomboid (Modded)'!
echo =======================================================================
pause
